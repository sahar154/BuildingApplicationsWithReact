import React from "react";

const PageNotFound = () => <h1>Oops! Page not found.</h1>;

export default PageNotFound;
